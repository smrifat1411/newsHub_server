const bdUrls = [
  "https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=UCxHoBXkY88Tb8z1Ssj6CWsQ&eventType=live&maxResults=2&q=live%20news&type=video&key=AIzaSyC3_VJQflvfqwDWW60P6Q-Mr5S28WUj3xE",
  "https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=UCUvXoiDEKI8VZJrr58g4VAw&eventType=live&maxResults=2&q=live%20news&type=video&key=AIzaSyC3_VJQflvfqwDWW60P6Q-Mr5S28WUj3xE",
  "https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=UC0ThmWmb7WQATrrDMLQph7Q&eventType=live&maxResults=2&q=live%20news&type=video&key=AIzaSyC3_VJQflvfqwDWW60P6Q-Mr5S28WUj3xE",
  "https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=UCbyLSj19ID4UnaSc3vcCl8Q&eventType=live&maxResults=2&q=live%20news&type=video&key=AIzaSyC3_VJQflvfqwDWW60P6Q-Mr5S28WUj3xE",
  "https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=UCKlhfq1ILoAFav7iw5iCnfA&eventType=live&maxResults=2&q=live%20news&type=video&key=AIzaSyC3_VJQflvfqwDWW60P6Q-Mr5S28WUj3xE",
  "https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=UCPREnbhKQP-hsVfsfKP-mCw&eventType=live&maxResults=2&q=live%20news&type=video&key=AIzaSyC3_VJQflvfqwDWW60P6Q-Mr5S28WUj3xE",
  "https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=UCN6sm8iHiPd0cnoUardDAnw&eventType=live&maxResults=2&q=live%20news&type=video&key=AIzaSyC3_VJQflvfqwDWW60P6Q-Mr5S28WUj3xE",
  "https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=UCHLqIOMPk20w-6cFgkA90jw&eventType=live&maxResults=2&q=live%20news&type=video&key=AIzaSyC3_VJQflvfqwDWW60P6Q-Mr5S28WUj3xE",
];

const worldUrls = [
  
    "https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=UCNye-wNBqNL5ZzHSJj3l8Bg&eventType=live&maxResults=1&q=live%20news&type=video&key=AIzaSyC3_VJQflvfqwDWW60P6Q-Mr5S28WUj3xE"
  ,
  
    "https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=UCBi2mrWuNuyYy4gbM6fU18Q&eventType=live&maxResults=1&q=live%20news&type=video&key=AIzaSyC3_VJQflvfqwDWW60P6Q-Mr5S28WUj3xE"
  ,
  
    "https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=UCknLrEdhRCp1aegoMqRaCZg&eventType=live&maxResults=1&q=live%20news&type=video&key=AIzaSyC3_VJQflvfqwDWW60P6Q-Mr5S28WUj3xE"
  ,
  
    "https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=UC83jt4dlz1Gjl58fzQrrKZg&eventType=live&maxResults=1&q=live%20news&type=video&key=AIzaSyC3_VJQflvfqwDWW60P6Q-Mr5S28WUj3xE"
  ,
  
    "https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=UCef1-8eOpJgud7szVPlZQAQ&eventType=live&maxResults=1&q=live%20news&type=video&key=AIzaSyC3_VJQflvfqwDWW60P6Q-Mr5S28WUj3xE"
  ,
  
    "https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=UCeY0bbntWzzVIaj2z3QigXg&eventType=live&maxResults=1&q=live%20news&type=video&key=AIzaSyC3_VJQflvfqwDWW60P6Q-Mr5S28WUj3xE"
  ,
];



module.exports={bdUrls,worldUrls}


